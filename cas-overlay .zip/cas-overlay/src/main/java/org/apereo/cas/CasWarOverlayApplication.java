package org.apereo.cas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasWarOverlayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasWarOverlayApplication.class, args);
	}
}
